from django.contrib import admin
from .models import ImUser
# Register your models here.

admin.site.register(ImUser)