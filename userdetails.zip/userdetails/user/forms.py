from django.db.models import fields
from django.forms import ModelForm
from.models import ImUser

class UserForm(ModelForm):
    class Meta:
        model = ImUser
        fields= '__all__'