from django.db import models

# Create your models here.

class ImUser(models.Model):
    name= models.CharField(max_length=200, null=False, blank=False)
    age= models.IntegerField(null=False, blank=False)
    location = models.CharField(max_length=200, null=False, blank=False)
    created=models.DateTimeField(auto_now_add=True)
    Aadhar_number=models.IntegerField(null=True,blank=False,unique=True)

    def __str__(self):
        return self.name
    
