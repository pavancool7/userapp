from os import name
from django.urls import path
from . import views


urlpatterns = [
    path('user/', views.user, name='user'),
    path('profile/<str:pk>/', views.profile, name= 'profile'),
    path('create-user/', views.createuser, name='create'),
    path('delete-user/<str:pk>', views.deleteuser, name='delete'),
    path('update-user/<str:pk>', views.updateuser, name='update'),
]
