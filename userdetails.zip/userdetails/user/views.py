from os import name
from django.shortcuts import redirect, render
from django.http import HttpResponse
from .models import ImUser
from .forms import UserForm
# Create your views here.

def user(request):
    users=ImUser.objects.all()

    context ={"users": users}
    return render(request, 'user.html' , context)


def profile(request,pk):
    user= ImUser.objects.get(name=pk)
    #print(user,pk)
    return render(request, 'profile.html',{"tar":user})

def createuser(request):
    form = UserForm()
    context={"form": form}
    if request.method =="POST":
        #print(request.POST)
        form=UserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect(user)

    return render(request, 'create.html', context)

def deleteuser(request, pk):
    user =ImUser.objects.get(name=pk)
    context={"user":user}
    if request.method == 'POST':
        user.delete()
        return redirect('user')        
    return render(request, 'delete.html', context)

def updateuser(request,pk):
    user=ImUser.objects.get(name=pk)
    form = UserForm(instance=user)
    if request.method == 'POST':
        #print(request.POST)
        form = UserForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return redirect('user')      
    context={"form": form}
    return render(request, 'update.html', context)





